package com.icu.yankiinsel.AKA;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.TextView;

import com.icu.yankiinsel.midterm_1.R;

public class MainRecyclerViewHolder extends RecyclerView.ViewHolder {

    public TextView mTextField;

    public Context context;

    public MainRecyclerViewHolder(View v) {
        super(v);
        mTextField = (TextView)  v.findViewById(R.id.cell_text);
        context = v.getContext();
    }

    public void bind(String string){
        mTextField.setText(string);
    }

}