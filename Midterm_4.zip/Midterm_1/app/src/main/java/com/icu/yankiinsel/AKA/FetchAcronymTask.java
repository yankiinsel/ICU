package com.icu.yankiinsel.AKA;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class FetchAcronymTask extends AsyncTask<String, Void, String[]> {


    MainRecyclerAdapter mAdapter;

    public FetchAcronymTask(MainRecyclerAdapter adapter) {
        mAdapter = adapter;
    }

    @Override
    protected String[] doInBackground(String... urlStrings) {


        HttpURLConnection urlConnection = null;
        BufferedReader reader = null;
        String acronymJsonStr = null;

        try {
            URL weatherURL = new URL(urlStrings[0]);
            urlConnection  = (HttpURLConnection) weatherURL.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            InputStream inputStream = urlConnection.getInputStream();
            StringBuffer buffer     = new StringBuffer();

            if (inputStream != null) {
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }
                if (buffer.length() != 0) {
                    acronymJsonStr = buffer.toString();
                }
            }
        } catch (IOException e) {
            Log.e("MainActivity", "Error ", e);
        } finally{
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (final IOException e) {
                    Log.e("MainActivity", "Error closing stream", e);
                }
            }
        }

        try {
            return getAcronymDataFromJson(acronymJsonStr);
        } catch (JSONException e) {
            Log.e("FetchAcronymTask", e.getMessage(), e);
        }

        // This will only happen if there was an error getting or parsing the forecast.
        return null;
    }

    private String[] getAcronymDataFromJson(String acronymJsonStr)
            throws JSONException {

        JSONArray acronymJSONArray  = new JSONArray(acronymJsonStr);


        Log.v("FetchAcronymTask", acronymJsonStr);
        //mAdapter.setJSONArray(acronymJSONArray);
        JSONObject acronymObject = acronymJSONArray.getJSONObject(0);
        JSONArray acronymsArray = acronymObject.getJSONArray("lfs");
        String[] resultStrs = new String[acronymsArray.length()];

        for(int i = 0; i < acronymsArray.length(); i++) {
            JSONObject acronym = acronymsArray.getJSONObject(i);
            int year = acronym.getInt("since");
            String name = acronym.getString("lf");
            String resultString = "(" + year + "), " + name;
            resultStrs[i] = resultString;
        }

        return resultStrs;
    }


    @Override
    protected void onPostExecute(String[] acronymInfo) {
        super.onPostExecute(acronymInfo);

        for(int i=0; i<acronymInfo.length; i++){
            Log.v("FetchWeatherTask", acronymInfo[i]);
        }
        mAdapter.setData(acronymInfo);
    }
}
