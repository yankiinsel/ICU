package com.icu.yankiinsel.AKA;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.icu.yankiinsel.midterm_1.R;

import java.util.ArrayList;
import java.util.List;

public class MainRecyclerAdapter  extends RecyclerView.Adapter<MainRecyclerViewHolder>  {

    private List<String> myDataset;
    private int mNumberItems;
    private String[] items;

    public MainRecyclerAdapter(String[] myDataset) {
        this.items = myDataset;
    }

    @Override
    public MainRecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        int layoutIdForListItem = R.layout.list_element;
        LayoutInflater inflater = LayoutInflater.from(context);
        boolean shouldAttachToParentImmediately = false;
        View view = inflater.inflate(layoutIdForListItem, parent, shouldAttachToParentImmediately);
        MainRecyclerViewHolder viewHolder = new MainRecyclerViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(MainRecyclerViewHolder holder, int position) {

        holder.bind(items[position]);
    }

    @Override
    public int getItemCount() {
        return items.length;
    }

    public void setData(String[] data) {

        items = data;
        mNumberItems = data.length;
        notifyDataSetChanged();
    }
}
